from .idf_monitor import main

if __name__ == '__main__':
    main()
