"""
.. include:: ../README.md
"""
__title__ = "pygdbmi"
__version__ = "0.9.0.2"
__author__ = "Chad Smith"
__copyright__ = "Copyright Chad Smith"
__pdoc__ = {"StringStream": False, "printcolor": False}
